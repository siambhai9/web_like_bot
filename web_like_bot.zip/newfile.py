import sqlite3
import requests
import time
import asyncio
import re
from flask import Flask, request, jsonify, render_template_string
import threading
from telethon import TelegramClient, events
from telethon.tl.custom import Button
from telethon import functions

# ==============================
# Database Setup
# ==============================
conn = sqlite3.connect("paidlike.db", check_same_thread=False)
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS paidlike_history(
    uid TEXT PRIMARY KEY,
    like_before INTEGER,
    like_after INTEGER,
    like_added INTEGER
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS bots(
    bot_token TEXT PRIMARY KEY,
    bot_username TEXT,
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS settings(
    key TEXT PRIMARY KEY,
    value TEXT
)
""")

conn.commit()


def save_like(uid, liked):
    cursor.execute(
        "INSERT OR REPLACE INTO paidlike_history(uid, like_before) VALUES(?, ?)",
        (uid, liked)
    )
    conn.commit()


def get_like(uid):
    cursor.execute(
        "SELECT like_before FROM paidlike_history WHERE uid=?",
        (uid,)
    )
    row = cursor.fetchone()
    return row[0] if row else 0


def update_like(uid, after, added):
    cursor.execute(
        "UPDATE paidlike_history SET like_after=?, like_added=? WHERE uid=?",
        (after, added, uid)
    )
    conn.commit()


def get_total_likes():
    cursor.execute("SELECT SUM(like_added) FROM paidlike_history")
    row = cursor.fetchone()
    return row[0] if row and row[0] else 0


def get_total_uids():
    cursor.execute("SELECT COUNT(*) FROM paidlike_history")
    row = cursor.fetchone()
    return row[0] if row else 0


def get_all_history():
    cursor.execute("SELECT uid, like_before, like_after, like_added FROM paidlike_history ORDER BY like_added DESC")
    rows = cursor.fetchall()
    return rows


def save_bot_token(bot_token, bot_username):
    cursor.execute(
        "INSERT OR REPLACE INTO bots(bot_token, bot_username) VALUES(?, ?)",
        (bot_token, bot_username)
    )
    conn.commit()


def get_all_bots():
    cursor.execute("SELECT bot_token, bot_username FROM bots")
    return cursor.fetchall()


def delete_bot(bot_token):
    cursor.execute("DELETE FROM bots WHERE bot_token=?", (bot_token,))
    conn.commit()


# ==============================
# Settings functions
# ==============================
DEFAULT_SETTINGS = {
    "sleep_seconds": "10",
    "source_group": "ff_like_bot_2025",
    "vip_group": "Community_FFBD",
    "vip_reply_timeout": "90",
}


def get_setting(key):
    cursor.execute("SELECT value FROM settings WHERE key=?", (key,))
    row = cursor.fetchone()
    if row:
        return row[0]
    default = DEFAULT_SETTINGS.get(key, "")
    if default:
        set_setting(key, default)
    return default


def set_setting(key, value):
    cursor.execute(
        "INSERT OR REPLACE INTO settings(key, value) VALUES(?, ?)",
        (key, str(value))
    )
    conn.commit()


def get_all_settings():
    settings = {}
    for key in DEFAULT_SETTINGS:
        settings[key] = get_setting(key)
    return settings


# ==============================
# Telegram API তথ্য
# ==============================
API_ID = 39111583
API_HASH = "d628a5ae837ff4d16c104f2bef3c5b2e"
SESSION_NAME = "my_telegram_session"

# /paidlike uid ধরার regex
PAIDLIKE_RE = re.compile(r"^/paidlike\s+(.+)$", re.IGNORECASE)
# /like uid regex — যে বট গুলো add হবে তাদের জন্য
LIKE_RE = re.compile(r"^/like\s+(.+)$", re.IGNORECASE)

client = TelegramClient(SESSION_NAME, API_ID, API_HASH)

app = Flask(__name__)

# Active bot clients dict: {bot_token: TelegramClient}
bot_clients = {}

# Like processing queue lock — একসাথে একটাই like request চলবে
like_queue_lock = asyncio.Lock()
like_queue_counter = 0


# ==============================
# VIP reply wait function
# ==============================
async def wait_for_vip_reply(sent_message, timeout=90):
    """
    VIP group-এ পাঠানো মেসেজের পর যে নতুন reply/message আসবে,
    সেটাকে bot reply হিসেবে ধরে নেয়া হবে।
    """
    vip_group = get_setting("vip_group")
    future = asyncio.get_event_loop().create_future()

    @client.on(events.NewMessage(chats=vip_group))
    async def handler(event):
        if future.done():
            return
        if event.message.id == sent_message.id:
            return
        if event.message.reply_to_msg_id == sent_message.id:
            future.set_result(event.message)
            return
        if event.message.id > sent_message.id and not event.out:
            future.set_result(event.message)

    try:
        return await asyncio.wait_for(future, timeout=timeout)
    finally:
        client.remove_event_handler(handler, events.NewMessage(chats=vip_group))


# ==============================
# Core async paidlike logic
# ==============================
async def process_paidlike(uid, wait_callback=None):
    """
    এই ফাংশনটি মূল paidlike processing করে।
    Telegram group handler, Flask API, এবং bot handler থেকেই কল করা যায়।
    wait_callback: একটি async function যা queue position পরিবর্তনে কল হবে।
    """
    global like_queue_counter

    # Settings থেকে মান পড়া
    sleep_seconds = int(get_setting("sleep_seconds"))
    vip_group = get_setting("vip_group")
    vip_timeout = int(get_setting("vip_reply_timeout"))

    command = f"/like {uid}"
    url = f"https://info.killersharmabot.online/level?uid={uid}"

    # Queue lock নেওয়া — একসাথে শুধু একটাই like request চলবে
    like_queue_counter += 1
    my_position = like_queue_counter

    if like_queue_lock.locked():
        if wait_callback:
            await wait_callback(f"⏳ আরেকটি like request চলছে... অপেক্ষা করুন (Queue Position: {my_position})")

    async with like_queue_lock:
        # প্রথম API Call — like_before জানার জন্য
        response = requests.get(url)

        if response.status_code != 200:
            return {
                "success": False,
                "message": "API Error - প্রথম API call ব্যর্থ হয়েছে"
            }

        info = response.json()

        nickname = info["name"]
        level = info["level"]
        exp = info["exp"]
        like_before = info["likes"]

        save_like(uid, like_before)

        try:
            # VIP group-এ Telegram account দিয়ে command পাঠান
            sent = await client.send_message(vip_group, command)

            # VIP group-এর bot reply অপেক্ষা করুন
            vip_reply = await wait_for_vip_reply(sent, timeout=vip_timeout)

            # Settings থেকে sleep seconds পড়া — like যুক্ত হতে সময় লাগে
            await asyncio.sleep(sleep_seconds)

            # আবার API Call — like_after জানার জন্য
            response = requests.get(url)

            if response.status_code != 200:
                return {
                    "success": False,
                    "message": "দ্বিতীয়বার API থেকে তথ্য পাওয়া যায়নি"
                }

            info = response.json()

            like_after = info["likes"]
            like_before_db = get_like(uid)
            like_added = like_after - like_before_db

            update_like(uid, like_after, like_added)

            vip_reply_text = vip_reply.text if vip_reply and vip_reply.text else None

            return {
                "success": True,
                "name": nickname,
                "uid": uid,
                "level": level,
                "exp": exp,
                "like": like_after,
                "like_before": like_before_db,
                "like_after": like_after,
                "like_added": like_added,
                "vip_reply": vip_reply_text
            }

        except asyncio.TimeoutError:
            return {
                "success": False,
                "message": f"VIP group থেকে {vip_timeout} seconds-এর মধ্যে কোনো reply পাওয়া যায়নি"
            }
        except Exception as e:
            return {
                "success": False,
                "message": f"Error: {str(e)}"
            }


# ==============================
# Bot Management — বট add/remove
# ==============================
async def start_bot_client(bot_token):
    """একটি bot token দিয়ে Telethon bot client তৈরি ও চালু করুন"""
    if bot_token in bot_clients:
        return True

    try:
        bot_client = TelegramClient(
            f"bot_{bot_token[:10]}",
            API_ID,
            API_HASH
        )
        await bot_client.start(bot_token=bot_token)

        # Bot info নিন
        me = await bot_client.get_me()
        bot_username = me.username

        # Database তে save
        save_bot_token(bot_token, bot_username)

        # /like {uid} handler register করুন
        @bot_client.on(events.NewMessage(pattern=LIKE_RE))
        async def bot_like_handler(event):
            uid = event.pattern_match.group(1).strip()

            if not uid:
                await event.reply("UID দিন। উদাহরণ: /like 123456789")
                return

            processing_msg = await event.reply("⏳ Processing your like request...")

            # Queue wait callback — ইউজারকে অপেক্ষা জানাবে
            async def bot_wait_cb(msg):
                try:
                    await processing_msg.edit(msg)
                except Exception:
                    pass

            result = await process_paidlike(uid, wait_callback=bot_wait_cb)

            if result["success"]:
                reply_text = f"""━━━━━━━━━━━━━━━━━━━━━━━━
👤 Nickname : {result['name']}
🆔 UID : {result['uid']}

🏅 Level : {result['level']}
⭐ EXP : {result['exp']}

❤️ Like Before : {result['like_before']}
❤️ Like After : {result['like_after']}
➕ Like Added : {result['like_added']}
━━━━━━━━━━━━━━━━━━━━━━━━"""
                await event.reply(reply_text)
            else:
                await event.reply(f"❌ {result['message']}")

            try:
                await processing_msg.delete()
            except Exception:
                pass

        bot_clients[bot_token] = bot_client
        print(f"Bot @{bot_username} started successfully!")
        return True

    except Exception as e:
        print(f"Bot start error: {e}")
        return False


async def stop_bot_client(bot_token):
    """একটি bot client বন্ধ করুন"""
    if bot_token in bot_clients:
        try:
            await bot_clients[bot_token].disconnect()
        except Exception:
            pass
        del bot_clients[bot_token]
    delete_bot(bot_token)


async def start_all_saved_bots():
    """Database এ saved সব bot চালু করুন"""
    bots = get_all_bots()
    for bot_token, bot_username in bots:
        await start_bot_client(bot_token)


# ==============================
# Telegram group handler — Source group
# ==============================
@client.on(events.NewMessage(pattern=PAIDLIKE_RE))
async def paidlike_handler(event):
    # Settings থেকে source_group পড়া — শুধু সেই group থেকে accept করবে
    source_group = get_setting("source_group")
    # চেক করা যে message সেই source group থেকে এসেছে কিনা
    chat = await event.get_chat()
    chat_username = getattr(chat, 'username', '') or ''
    if chat_username.lower() != source_group.lower() and str(chat.id) != source_group:
        return

    uid = event.pattern_match.group(1).strip()

    if not uid:
        await event.reply("UID দিন। উদাহরণ: /paidlike 123456789")
        return

    processing_msg = await event.reply("⏳ Processing your paidlike request...")

    # Queue wait callback
    async def group_wait_cb(msg):
        try:
            await processing_msg.edit(msg)
        except Exception:
            pass

    result = await process_paidlike(uid, wait_callback=group_wait_cb)

    if result["success"]:
        vip_reply_text = result.get("vip_reply", "")
        reply_text = f"""{vip_reply_text if vip_reply_text else ""}

━━━━━━━━━━━━━━━━━━━━━━━━
👤 Nickname : {result['name']}
🆔 UID : {result['uid']}

🏅 Level : {result['level']}
⭐ EXP : {result['exp']}

❤️ Like Before : {result['like_before']}
❤️ Like After : {result['like_after']}
➕ Like Added : {result['like_added']}
━━━━━━━━━━━━━━━━━━━━━━━━"""
        await event.reply(reply_text)
    else:
        await event.reply(f"❌ {result['message']}")

    try:
        await processing_msg.delete()
    except Exception:
        pass


# ==============================
# Flask HTML Templates
# ==============================
DASHBOARD_HTML = """
<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🔥 PaidLike Dashboard</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #0f0c29, #302b63, #24243e);
            min-height: 100vh;
            color: #fff;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            padding: 30px 20px;
        }
        h1 {
            text-align: center;
            font-size: 2.2em;
            margin-bottom: 10px;
            text-shadow: 0 0 20px rgba(255, 107, 53, 0.6);
        }
        .subtitle {
            text-align: center;
            color: #aaa;
            margin-bottom: 40px;
            font-size: 0.95em;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }
        .stat-card {
            background: rgba(255,255,255,0.07);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 16px;
            padding: 25px;
            text-align: center;
            backdrop-filter: blur(10px);
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 40px rgba(255, 107, 53, 0.2);
        }
        .stat-icon {
            font-size: 2.5em;
            margin-bottom: 10px;
        }
        .stat-value {
            font-size: 2.8em;
            font-weight: bold;
            color: #ff6b35;
            text-shadow: 0 0 15px rgba(255, 107, 53, 0.4);
        }
        .stat-label {
            color: #bbb;
            margin-top: 5px;
            font-size: 0.95em;
        }
        .section-title {
            font-size: 1.5em;
            margin-bottom: 20px;
            padding-left: 10px;
            border-left: 4px solid #ff6b35;
        }
        .history-table {
            width: 100%;
            border-collapse: collapse;
            background: rgba(255,255,255,0.05);
            border-radius: 12px;
            overflow: hidden;
            margin-bottom: 40px;
        }
        .history-table th {
            background: rgba(255, 107, 53, 0.3);
            padding: 14px 16px;
            text-align: left;
            font-weight: 600;
        }
        .history-table td {
            padding: 12px 16px;
            border-bottom: 1px solid rgba(255,255,255,0.06);
        }
        .history-table tr:hover td {
            background: rgba(255,255,255,0.04);
        }
        .like-added {
            color: #4ade80;
            font-weight: bold;
        }
        .btn-add-bot {
            display: inline-block;
            background: linear-gradient(135deg, #ff6b35, #ff3e3e);
            color: white;
            border: none;
            padding: 14px 32px;
            font-size: 1.1em;
            border-radius: 50px;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            font-weight: 600;
            box-shadow: 0 5px 25px rgba(255, 107, 53, 0.4);
        }
        .btn-add-bot:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 35px rgba(255, 107, 53, 0.6);
        }
        .btn-center {
            text-align: center;
            margin-bottom: 40px;
        }
        .bot-list {
            margin-bottom: 40px;
        }
        .bot-card {
            background: rgba(255,255,255,0.07);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 12px;
            padding: 18px 22px;
            margin-bottom: 12px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            backdrop-filter: blur(10px);
        }
        .bot-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .bot-avatar {
            width: 42px;
            height: 42px;
            background: linear-gradient(135deg, #ff6b35, #ff3e3e);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2em;
        }
        .bot-name {
            font-weight: 600;
            font-size: 1.05em;
        }
        .bot-token-display {
            color: #888;
            font-size: 0.85em;
            font-family: monospace;
        }
        .btn-remove {
            background: rgba(239, 68, 68, 0.2);
            border: 1px solid rgba(239, 68, 68, 0.4);
            color: #ef4444;
            padding: 8px 18px;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s;
            font-size: 0.9em;
        }
        .btn-remove:hover {
            background: rgba(239, 68, 68, 0.4);
        }
        .empty-state {
            text-align: center;
            padding: 40px;
            color: #777;
        }
        .empty-state .icon {
            font-size: 3em;
            margin-bottom: 15px;
        }
        .api-info {
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 30px;
        }
        .api-info h3 {
            margin-bottom: 10px;
            color: #ff6b35;
        }
        .api-info code {
            background: rgba(0,0,0,0.3);
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 0.9em;
        }
        .api-info p {
            margin: 8px 0;
            color: #ccc;
            line-height: 1.6;
        }
        /* Settings Section */
        .settings-section {
            background: rgba(255,255,255,0.07);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 16px;
            padding: 25px;
            margin-bottom: 40px;
            backdrop-filter: blur(10px);
        }
        .settings-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        .setting-item {
            background: rgba(0,0,0,0.2);
            border: 1px solid rgba(255,255,255,0.08);
            border-radius: 12px;
            padding: 18px;
        }
        .setting-item label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #ddd;
            font-size: 0.95em;
        }
        .setting-item .setting-desc {
            color: #888;
            font-size: 0.82em;
            margin-bottom: 10px;
        }
        .setting-item input[type="text"],
        .setting-item input[type="number"] {
            width: 100%;
            padding: 12px 14px;
            border: 1px solid rgba(255,255,255,0.15);
            border-radius: 8px;
            background: rgba(0,0,0,0.3);
            color: #fff;
            font-size: 1em;
            transition: border-color 0.3s;
        }
        .setting-item input:focus {
            outline: none;
            border-color: #ff6b35;
            box-shadow: 0 0 10px rgba(255, 107, 53, 0.2);
        }
        .btn-save-settings {
            display: block;
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #ff6b35, #ff3e3e);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 1.1em;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            box-shadow: 0 5px 25px rgba(255, 107, 53, 0.3);
        }
        .btn-save-settings:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 35px rgba(255, 107, 53, 0.5);
        }
        .settings-message {
            text-align: center;
            padding: 12px;
            border-radius: 8px;
            margin-top: 15px;
            font-size: 0.95em;
            display: none;
        }
        .settings-message.success {
            background: rgba(74, 222, 128, 0.15);
            border: 1px solid rgba(74, 222, 128, 0.3);
            color: #4ade80;
            display: block;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔥 PaidLike Dashboard</h1>
        <p class="subtitle">Like request ম্যানেজমেন্ট প্যানেল</p>

        <!-- Stats Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">❤️</div>
                <div class="stat-value">{{ total_likes }}</div>
                <div class="stat-label">টোটাল Like দেওয়া হয়েছে</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">👥</div>
                <div class="stat-value">{{ total_uids }}</div>
                <div class="stat-label">টোটাল UID তে Request পাঠানো হয়েছে</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">🤖</div>
                <div class="stat-value">{{ total_bots }}</div>
                <div class="stat-label">Active Bot</div>
            </div>
        </div>

        <!-- Settings Section -->
        <h2 class="section-title">⚙️ Settings</h2>
        <div class="settings-section">
            {% if settings_msg %}
            <div class="settings-message success">{{ settings_msg }}</div>
            {% endif %}
            <form action="/savesettings" method="POST">
                <div class="settings-grid">
                    <div class="setting-item">
                        <label>💤 Sleep Seconds</label>
                        <div class="setting-desc">Like রেজাল্ট আসার পর কত সেকেন্ড wait করবে (ডিফল্ট: 10)</div>
                        <input type="number" name="sleep_seconds" value="{{ settings.sleep_seconds }}" min="1" max="120">
                    </div>
                    <div class="setting-item">
                        <label>📢 Source Group</label>
                        <div class="setting-desc">যে গ্রুপে /paidlike কমান্ড শুনবে (username বা ID)</div>
                        <input type="text" name="source_group" value="{{ settings.source_group }}" placeholder="ff_like_bot_2025">
                    </div>
                    <div class="setting-item">
                        <label>👑 VIP Group</label>
                        <div class="setting-desc">Like কমান্ড পাঠানোর গ্রুপ (username বা ID)</div>
                        <input type="text" name="vip_group" value="{{ settings.vip_group }}" placeholder="Community_FFBD">
                    </div>
                    <div class="setting-item">
                        <label>⏱️ VIP Reply Timeout</label>
                        <div class="setting-desc">VIP গ্রুপে কত সেকেন্ড reply এর জন্য wait করবে (ডিফল্ট: 90)</div>
                        <input type="number" name="vip_reply_timeout" value="{{ settings.vip_reply_timeout }}" min="10" max="300">
                    </div>
                </div>
                <button type="submit" class="btn-save-settings">💾 Save Settings</button>
            </form>
        </div>

        <!-- API Info -->
        <div class="api-info">
            <h3>📡 API Endpoint</h3>
            <p><code>GET /like?uid={uid}</code> — UID দিয়ে like request পাঠান</p>
            <p><code>GET /api/stats</code> — JSON format এ stats দেখুন</p>
            <p><code>GET /api/history</code> — JSON format এ সব history দেখুন</p>
            <p><code>GET /api/settings</code> — JSON format এ সব settings দেখুন</p>
        </div>

        <!-- History Table -->
        <h2 class="section-title">📊 Like History</h2>
        {% if history %}
        <table class="history-table">
            <thead>
                <tr>
                    <th>UID</th>
                    <th>Like Before</th>
                    <th>Like After</th>
                    <th>Like Added</th>
                </tr>
            </thead>
            <tbody>
                {% for row in history %}
                <tr>
                    <td>{{ row[0] }}</td>
                    <td>{{ row[1] }}</td>
                    <td>{{ row[2] }}</td>
                    <td class="like-added">+{{ row[3] }}</td>
                </tr>
                {% endfor %}
            </tbody>
        </table>
        {% else %}
        <div class="empty-state">
            <div class="icon">📊</div>
            <p>কোনো like history পাওয়া যায়নি</p>
        </div>
        {% endif %}

        <!-- Add Bot Button -->
        <div class="btn-center">
            <a href="/addbot" class="btn-add-bot">🤖 Add Bot</a>
        </div>

        <!-- Bot List -->
        <h2 class="section-title">🤖 Active Bots</h2>
        {% if bots %}
        <div class="bot-list">
            {% for bot in bots %}
            <div class="bot-card">
                <div class="bot-info">
                    <div class="bot-avatar">🤖</div>
                    <div>
                        <div class="bot-name">@{{ bot[1] }}</div>
                        <div class="bot-token-display">{{ bot[0][:15] }}...</div>
                    </div>
                </div>
                <form action="/removebot" method="POST" style="display:inline;">
                    <input type="hidden" name="bot_token" value="{{ bot[0] }}">
                    <button type="submit" class="btn-remove">🗑 Remove</button>
                </form>
            </div>
            {% endfor %}
        </div>
        {% else %}
        <div class="empty-state">
            <div class="icon">🤖</div>
            <p>কোনো bot add করা হয়নি। "Add Bot" বাটনে ক্লিক করে bot add করুন।</p>
        </div>
        {% endif %}
    </div>
</body>
</html>
"""

ADD_BOT_HTML = """
<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🤖 Add Bot — PaidLike</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #0f0c29, #302b63, #24243e);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
        }
        .card {
            background: rgba(255,255,255,0.08);
            border: 1px solid rgba(255,255,255,0.12);
            border-radius: 20px;
            padding: 40px;
            width: 450px;
            max-width: 95vw;
            backdrop-filter: blur(15px);
        }
        h2 {
            text-align: center;
            font-size: 1.8em;
            margin-bottom: 8px;
        }
        .subtitle {
            text-align: center;
            color: #aaa;
            margin-bottom: 30px;
            font-size: 0.9em;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #ddd;
        }
        input[type="text"] {
            width: 100%;
            padding: 14px 16px;
            border: 1px solid rgba(255,255,255,0.15);
            border-radius: 10px;
            background: rgba(0,0,0,0.3);
            color: #fff;
            font-size: 1em;
            transition: border-color 0.3s;
        }
        input[type="text"]:focus {
            outline: none;
            border-color: #ff6b35;
            box-shadow: 0 0 15px rgba(255, 107, 53, 0.2);
        }
        input[type="text"]::placeholder {
            color: #666;
        }
        .btn-submit {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #ff6b35, #ff3e3e);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 1.1em;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            box-shadow: 0 5px 25px rgba(255, 107, 53, 0.3);
        }
        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 35px rgba(255, 107, 53, 0.5);
        }
        .btn-back {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #aaa;
            text-decoration: none;
            transition: color 0.3s;
        }
        .btn-back:hover {
            color: #ff6b35;
        }
        .message {
            text-align: center;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 0.95em;
        }
        .message.success {
            background: rgba(74, 222, 128, 0.15);
            border: 1px solid rgba(74, 222, 128, 0.3);
            color: #4ade80;
        }
        .message.error {
            background: rgba(239, 68, 68, 0.15);
            border: 1px solid rgba(239, 68, 68, 0.3);
            color: #ef4444;
        }
        .info-box {
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 25px;
            font-size: 0.88em;
            color: #bbb;
            line-height: 1.6;
        }
        .info-box strong {
            color: #ff6b35;
        }
    </style>
</head>
<body>
    <div class="card">
        <h2>🤖 Add Bot</h2>
        <p class="subtitle">Telegram Bot Token দিয়ে bot add করুন</p>

        {% if message %}
        <div class="message {{ msg_type }}">{{ message }}</div>
        {% endif %}

        <div class="info-box">
            <strong>📌 কিভাবে Bot Token পাবেন?</strong><br>
            1. Telegram-এ <strong>@BotFather</strong> এ যান<br>
            2. <code>/newbot</code> বা <code>/mybots</code> কমান্ড দিন<br>
            3. Bot Token কপি করে নিচে পেস্ট করুন<br><br>
            <strong>💡 Bot add হলে:</strong> ওই bot এ <code>/like {uid}</code> দিলে like request পাঠাবে এবং name, level, exp, like before, like after, like added রিপ্লাই করবে।
        </div>

        <form action="/addbot" method="POST">
            <div class="form-group">
                <label for="bot_token">🔑 Bot Token</label>
                <input type="text" id="bot_token" name="bot_token"
                       placeholder="যেমন: 123456789:ABCdefGHIjklMNOpqrsTUVwxyz"
                       required>
            </div>
            <button type="submit" class="btn-submit">✅ Save & Start Bot</button>
        </form>

        <a href="/" class="btn-back">← Dashboard এ ফিরে যান</a>
    </div>
</body>
</html>
"""


# ==============================
# Flask Routes
# ==============================
telethon_loop = None


@app.route("/", methods=["GET"])
def dashboard():
    """Dashboard — টোটাল like, UID count, history, bot list, settings দেখায়"""
    total_likes = get_total_likes()
    total_uids = get_total_uids()
    history = get_all_history()
    bots = get_all_bots()
    total_bots = len(bots)
    settings = get_all_settings()

    settings_msg = request.args.get("settings_msg", "")

    return render_template_string(
        DASHBOARD_HTML,
        total_likes=total_likes,
        total_uids=total_uids,
        total_bots=total_bots,
        history=history,
        bots=bots,
        settings=settings,
        settings_msg=settings_msg
    )


@app.route("/savesettings", methods=["POST"])
def save_settings():
    """Settings save করুন ড্যাশবোর্ড থেকে"""
    sleep_seconds = request.form.get("sleep_seconds", "10").strip()
    source_group = request.form.get("source_group", "").strip()
    vip_group = request.form.get("vip_group", "").strip()
    vip_reply_timeout = request.form.get("vip_reply_timeout", "90").strip()

    if source_group:
        set_setting("source_group", source_group)
    if vip_group:
        set_setting("vip_group", vip_group)

    try:
        sleep_val = int(sleep_seconds)
        if sleep_val < 1:
            sleep_val = 1
        if sleep_val > 120:
            sleep_val = 120
        set_setting("sleep_seconds", str(sleep_val))
    except ValueError:
        pass

    try:
        timeout_val = int(vip_reply_timeout)
        if timeout_val < 10:
            timeout_val = 10
        if timeout_val > 300:
            timeout_val = 300
        set_setting("vip_reply_timeout", str(timeout_val))
    except ValueError:
        pass

    return """
    <script>
        window.location.href = '/?settings_msg=✅ Settings সফলভাবে সেভ হয়েছে!';
    </script>
    """


@app.route("/addbot", methods=["GET", "POST"])
def add_bot_page():
    """Add Bot পেজ — bot token নিয়ে ও save করে"""
    global telethon_loop

    if request.method == "GET":
        return render_template_string(ADD_BOT_HTML, message=None, msg_type=None)

    # POST — bot token save
    bot_token = request.form.get("bot_token", "").strip()

    if not bot_token:
        return render_template_string(
            ADD_BOT_HTML,
            message="Bot Token দিন!",
            msg_type="error"
        )

    if telethon_loop is None or not telethon_loop.is_running():
        return render_template_string(
            ADD_BOT_HTML,
            message="Telegram client ready নয়। কিছুক্ষণ পর চেষ্টা করুন।",
            msg_type="error"
        )

    # Bot client চালু করুন
    future = asyncio.run_coroutine_threadsafe(start_bot_client(bot_token), telethon_loop)

    try:
        success = future.result(timeout=30)
    except Exception as e:
        return render_template_string(
            ADD_BOT_HTML,
            message=f"Bot start error: {str(e)}",
            msg_type="error"
        )

    if success:
        return render_template_string(
            ADD_BOT_HTML,
            message="✅ Bot সফলভাবে add ও চালু হয়েছে! এখন আপনার bot এ /like {uid} দিন।",
            msg_type="success"
        )
    else:
        return render_template_string(
            ADD_BOT_HTML,
            message="❌ Bot start করা যায়নি। Token সঠিক কিনা চেক করুন।",
            msg_type="error"
        )


@app.route("/removebot", methods=["POST"])
def remove_bot_page():
    """Bot remove করুন"""
    global telethon_loop

    bot_token = request.form.get("bot_token", "").strip()

    if bot_token and telethon_loop and telethon_loop.is_running():
        future = asyncio.run_coroutine_threadsafe(stop_bot_client(bot_token), telethon_loop)
        try:
            future.result(timeout=15)
        except Exception:
            pass

    # Dashboard এ redirect
    return """
    <script>
        window.location.href = '/';
    </script>
    """


@app.route("/like", methods=["GET"])
def api_like():
    """API endpoint: /like?uid={uid}"""
    global telethon_loop

    uid = request.args.get("uid", "").strip()

    if not uid:
        return jsonify({
            "success": False,
            "message": "UID দিন। উদাহরণ: /like?uid=123456789"
        }), 400

    if telethon_loop is None or not telethon_loop.is_running():
        return jsonify({
            "success": False,
            "message": "Telegram client এখনো ready হয়নি। কিছুক্ষণ পর আবার চেষ্টা করুন।"
        }), 503

    future = asyncio.run_coroutine_threadsafe(process_paidlike(uid), telethon_loop)

    try:
        result = future.result(timeout=150)
    except asyncio.TimeoutError:
        return jsonify({
            "success": False,
            "message": "API request timeout — অনেক সময় নিয়েছে"
        }), 504
    except Exception as e:
        return jsonify({
            "success": False,
            "message": f"Error: {str(e)}"
        }), 500

    return jsonify(result)


@app.route("/api/stats", methods=["GET"])
def api_stats():
    """JSON format এ stats"""
    return jsonify({
        "total_likes": get_total_likes(),
        "total_uids": get_total_uids(),
        "active_bots": len(bot_clients)
    })


@app.route("/api/history", methods=["GET"])
def api_history():
    """JSON format এ সব history"""
    history = get_all_history()
    result = []
    for row in history:
        result.append({
            "uid": row[0],
            "like_before": row[1],
            "like_after": row[2],
            "like_added": row[3]
        })
    return jsonify(result)


@app.route("/api/bots", methods=["GET"])
def api_bots():
    """JSON format এ active bots"""
    bots = get_all_bots()
    result = []
    for bot_token, bot_username in bots:
        result.append({
            "bot_username": bot_username,
            "active": bot_token in bot_clients
        })
    return jsonify(result)


@app.route("/api/settings", methods=["GET"])
def api_settings():
    """JSON format এ সব settings"""
    return jsonify(get_all_settings())


@app.route("/api/settings", methods=["POST"])
def api_update_settings():
    """API দিয়ে settings update করুন"""
    data = request.get_json(force=True, silent=True) or {}
    for key in DEFAULT_SETTINGS:
        if key in data:
            set_setting(key, str(data[key]))
    return jsonify({"success": True, "settings": get_all_settings()})


# ==============================
# Main — Telegram client + Flask একসাথে চালানো
# ==============================
async def main():
    global telethon_loop

    print("Starting Telegram relay userbot...")
    await client.start()
    print("Logged in successfully.")

    telethon_loop = asyncio.get_event_loop()

    # Database এ saved সব bot চালু করুন
    await start_all_saved_bots()

    # Settings থেকে source_group পড়া
    source_group = get_setting("source_group")
    print(f"Listening for /paidlike commands in source group: {source_group}")

    # Flask server আলাদা thread-এ চালান — non-blocking
    flask_thread = threading.Thread(
        target=lambda: app.run(host="0.0.0.0", port=5000, use_reloader=False),
        daemon=True
    )
    flask_thread.start()
    print("Flask server started on http://0.0.0.0:5000")
    print("Dashboard: http://0.0.0.0:5000/")
    print("API endpoint: http://0.0.0.0:5000/like?uid={uid}")
    print("Settings API: http://0.0.0.0:5000/api/settings")

    # Telethon client চালিয়ে যান
    await client.run_until_disconnected()


if __name__ == "__main__":
    with client:
        client.loop.run_until_complete(main())
